<?php /* Smarty version Smarty-3.1.15, created on 2017-02-19 19:47:43
         compiled from "/home/abppt/public_html/agendamento/templates/presentation/presentation.tpl" */ ?>
<?php /*%%SmartyHeaderCode:90908599258a9ef90128b79-11707357%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5e09a94169022df19b64fd3c373fd9b48132acaa' => 
    array (
      0 => '/home/abppt/public_html/agendamento/templates/presentation/presentation.tpl',
      1 => 1487533662,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '90908599258a9ef90128b79-11707357',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_58a9ef925f6b09_58663969',
  'variables' => 
  array (
    'BASE_URL' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58a9ef925f6b09_58663969')) {function content_58a9ef925f6b09_58663969($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('common/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>



<p>Bem vindo à página de Calendarização da Associação de Basquete do Porto!</p>
<br>
<p>Após obteres e efectuares o teu login estes são os passos seguintes: </p>
<br>


<br>
<h3><b>1 - Criação de equipas</b></h3>
<br>

<p>No canto superior esquerdo do ecrã seleciona a tab "Conta" e em seguida seleciona "Gestão de Equipas".</p>
<p>Esta página permite adicionar ou remover equipas associadas a um certo escalão.</p>
<br>
<img src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
images/assets/Gestao_de_equipas.JPG" alt="Gestao de equipas" style="width:700px;height:300px;">
<p style="color:cyan;">1 - Esta zona permite-te gerir e remover as tuas equipas</p>
<p style="color:red;">2 - Esta zona permite-te adicionar novas equipas, para tal basta selecionar o escalão da equipa a criar e carregar em nova equipa.</p>

<br>
<h3><b>2 - Agendamento de equipas</b></h3>
<br>

<p>Após criares as tuas equipas podes agora disponibilizar cada uma das tuas equipas para um determinado dia.</p>
<p>Para tal seleciona no canto superior esquerdo do ecrã o escalão da equipa a agendar e posteriormente a equipa desejada.</p>
<p>Esta página é a página de agendamento.</p>
<br>
<img src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
images/assets/Agendamento.JPG" alt="Agendamento" style="width:700px;height:300px;">
<p style="color:cyan;">1 - O calendário permite-te selecioar o dia que pretendes disponibilizar a tua equipa.</p>
<p style="color:red;">2 - Após selecionares o dia no caléndario basta apenas selecionar que pretendes participar num dos dois horarios(ou ambos) e confirmar no butão "Registar equipa" para cada horário</p>
<p style="color:red;">Podes ainda informar se estás disponivel para organizar o evento nesse dia</p>

<br>
<h3><b>3 - Mudança de password(opcional)</b></h3>
<br>
<p>Podes a qualquer altura alterar a tua password.</p>
<p>No canto superior esquerdo do ecrã seleciona a tab "Conta" e em seguida seleciona "Alteração de Password". </p>
<p>Na nova página basta preencheres o formulário com a informação pedida(password actual, nova password e repetição da mesma) e pressionar o butão "Confirmar"</p>
<br>
<br>
<?php echo $_smarty_tpl->getSubTemplate ('common/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
