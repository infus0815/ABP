<?php /* Smarty version Smarty-3.1.15, created on 2017-02-19 19:18:42
         compiled from "/home/abppt/public_html/agendamento/templates/common/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:157411055458a9ef92909ba4-84405792%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7809989c14cbbc5fad36e77d75043c302615eb06' => 
    array (
      0 => '/home/abppt/public_html/agendamento/templates/common/footer.tpl',
      1 => 1472131764,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '157411055458a9ef92909ba4-84405792',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_58a9ef9290ac67_21526751',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58a9ef9290ac67_21526751')) {function content_58a9ef9290ac67_21526751($_smarty_tpl) {?>	</div>
	<footer>

	</footer>
  </body>
</html>
<?php }} ?>
