<?php /* Smarty version Smarty-3.1.15, created on 2017-02-19 13:07:55
         compiled from "\XAMPP\htdocs\ABP\templates\presentation\presentation.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2320857e55b4d7b7c33-08241330%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '75322416c1b8dc3db9e878655b0b69b5911ef01a' => 
    array (
      0 => '\\XAMPP\\htdocs\\ABP\\templates\\presentation\\presentation.tpl',
      1 => 1487505864,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2320857e55b4d7b7c33-08241330',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_57e55b4dee79d2_00893587',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57e55b4dee79d2_00893587')) {function content_57e55b4dee79d2_00893587($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('common/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>



Bem vindo ao Associação de Basquete do Porto!

(aqui será a página de apresentação se existir) 

<?php echo $_smarty_tpl->getSubTemplate ('common/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
