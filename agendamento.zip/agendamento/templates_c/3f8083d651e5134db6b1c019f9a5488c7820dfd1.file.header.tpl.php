<?php /* Smarty version Smarty-3.1.15, created on 2017-02-19 19:18:42
         compiled from "/home/abppt/public_html/agendamento/templates/common/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:98287656258a9ef92740137-16843374%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3f8083d651e5134db6b1c019f9a5488c7820dfd1' => 
    array (
      0 => '/home/abppt/public_html/agendamento/templates/common/header.tpl',
      1 => 1487520978,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '98287656258a9ef92740137-16843374',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'BASE_URL' => 0,
    'USERNAME' => 0,
    'escaloes' => 0,
    'escalao_id' => 0,
    'escalao' => 0,
    'equipaEscaloes' => 0,
    'equipaEscalao' => 0,
    'ERROR_MESSAGES_LOGIN' => 0,
    'error' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_58a9ef92887781_66239329',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58a9ef92887781_66239329')) {function content_58a9ef92887781_66239329($_smarty_tpl) {?><!DOCTYPE html>
<html>
<head>
    <title>ABP</title>
    <meta charset='utf-8'>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"
          rel="stylesheet" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7"
          crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
lib/jquery-ui/jquery-ui.min.css">
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
css/style.css">
    <script
            src="https://code.jquery.com/jquery-2.2.3.js"
            integrity="sha256-laXWtGydpwqJ8JA+X9x2miwmaiKhn8tVmOVEigRNtP4="
            crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"
            integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS"
            crossorigin="anonymous"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
lib/jquery-ui/jquery-ui.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
javascript/main.js"></script>
</head>

<body>

<nav class="navbar navbar-default" >
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/presentation/presentation.php">ABP</a>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse" id="menu">
            <?php if ($_smarty_tpl->tpl_vars['USERNAME']->value) {?>
                <ul class="nav navbar-nav">

                    <?php  $_smarty_tpl->tpl_vars['escalao'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['escalao']->_loop = false;
 $_smarty_tpl->tpl_vars['escalao_id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['escaloes']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['escalao']->key => $_smarty_tpl->tpl_vars['escalao']->value) {
$_smarty_tpl->tpl_vars['escalao']->_loop = true;
 $_smarty_tpl->tpl_vars['escalao_id']->value = $_smarty_tpl->tpl_vars['escalao']->key;
?>
                        <li  class="dropdown" id="escalao_<?php echo $_smarty_tpl->tpl_vars['escalao_id']->value;?>
">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Mini <?php echo $_smarty_tpl->tpl_vars['escalao']->value;?>
<span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <?php  $_smarty_tpl->tpl_vars['equipaEscalao'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['equipaEscalao']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['equipaEscaloes']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['equipaEscalao']->key => $_smarty_tpl->tpl_vars['equipaEscalao']->value) {
$_smarty_tpl->tpl_vars['equipaEscalao']->_loop = true;
?>
                                    <?php if ($_smarty_tpl->tpl_vars['equipaEscalao']->value['escalao_id']==$_smarty_tpl->tpl_vars['escalao_id']->value) {?>
                                        <li><a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/calendar/calendar.php?escalao_id=<?php echo $_smarty_tpl->tpl_vars['escalao_id']->value;?>
&equipaescalao_id=<?php echo $_smarty_tpl->tpl_vars['equipaEscalao']->value['equipaescalao_id'];?>
">Mini <?php echo $_smarty_tpl->tpl_vars['escalao']->value;?>
 <?php echo $_smarty_tpl->tpl_vars['equipaEscalao']->value['equipaescalao_nome'];?>
</a></li>
                                    <?php }?>
                                <?php } ?>
                            </ul>
                        </li>
                    <?php } ?>
                    <li class="dropdown" id="nav_profile"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Conta<span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <?php if ($_smarty_tpl->tpl_vars['USERNAME']->value!="admin") {?>
                                <li><a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/conta/gestao_equipas.php">Gestão de Equipas</a></li>
                            <?php }?>
                            <li><a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/conta/alteracao_password.php">Alteração de Password</a></li>
                        </ul>
                    </li>
                    <?php if ($_smarty_tpl->tpl_vars['USERNAME']->value=="admin") {?>
                        <li class="dropdown" id="admin"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Administração<span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/admin/equipas.php">Gestão de Contas</a></li>
                                <li><a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/admin/gestao_meses.php">Bloqueio de Meses</a></li>
                            </ul>
                        </li>
                    <?php }?>
                    <!-- <li><a id="nav_historico" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
">Histórico</a></li> -->
                </ul>
                <ul class="navbar-form navbar-right">
                    <form action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/equipas/logout.php"">
                    <?php if ($_smarty_tpl->tpl_vars['USERNAME']->value=="admin") {?>
                        <label style="color:#ff4d4d; padding-right:10px">Administrador</label>
                    <?php } else { ?>
                        <label style="color:white; padding-right:10px"><?php echo $_smarty_tpl->tpl_vars['USERNAME']->value;?>
</label>
                    <?php }?>
                    <button type="submit" class="btn"><span class="glyphicon glyphicon-log-out"></span> Logout</button>
                    </form>
                </ul>
            <?php } else { ?>
                <ul class="navbar-form navbar-right">
                    <form action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/equipas/login.php" method="post" enctype="multipart/form-data" class="navbar-form navbar-right">
                        <input type="text" placeholder="username" name="username" class="form-control">
                        <input type="password" placeholder="password" name="password" class="form-control">
                        <button type="submit" class="btn"><span class="glyphicon glyphicon-log-in"></span> Login</button>
                    </form>

                </ul>

            <?php }?>
        </div>
    </div>

    <div id="error_messages">
        <?php  $_smarty_tpl->tpl_vars['error'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['error']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ERROR_MESSAGES_LOGIN']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['error']->key => $_smarty_tpl->tpl_vars['error']->value) {
$_smarty_tpl->tpl_vars['error']->_loop = true;
?>
            <div class="error"><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
<a class="close" href="#">X</a></div>
        <?php } ?>
    </div>

</nav>



<div class="container-fluid">



<?php }} ?>
