<?php /* Smarty version Smarty-3.1.15, created on 2017-02-19 13:07:56
         compiled from "\XAMPP\htdocs\ABP\templates\common\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2186257e55b4ea843c3-51396482%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5cb18892ef2322f88dc4d61d1e484f15af9b5f21' => 
    array (
      0 => '\\XAMPP\\htdocs\\ABP\\templates\\common\\footer.tpl',
      1 => 1487505864,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2186257e55b4ea843c3-51396482',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_57e55b4ea914c9_81045158',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57e55b4ea914c9_81045158')) {function content_57e55b4ea914c9_81045158($_smarty_tpl) {?>	</div>
	<footer>

	</footer>
  </body>
</html>
<?php }} ?>
