BASE_URL = '/agendamento/';
//BASE_URL = 'https://abptest.herokuapp.com/';

 $(document).ready(function() {
   initMessageClosers();
 });

 function initMessageClosers() {
  $('.close').click(function() {
    $(this).parent().fadeOut();
  });
 }

